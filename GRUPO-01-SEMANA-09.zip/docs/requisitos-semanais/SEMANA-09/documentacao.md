# Entrega da Semana 09 — Integração das Funcionalidades

**Versão:** 2.0 — RF-005 hospedagem e RF-006 reservas/consulta médica  
**Laboratório de Inovação — Prof. Edilberto Silva — 2026**  
**Formato:** Markdown  
**Grupo:** Grupo 1 - Petshop  
**Integrantes:** Isabela Rezende; Mateus Alcântara; João Paulo Arruda.

**ID:** RF-005 / RF-006 — SEMANA-09  
**Título:** Hospedagem (Semana 8), reservas e consulta médica (Semana 9)  
**Tipo:** Requisitos Funcionais  
**Prioridade:** ALTA  
**Justificativa da prioridade:** a integração é necessária para demonstrar, em um fluxo único, as funcionalidades desenvolvidas anteriormente e validar a navegação entre elas.  
**Complexidade:** MÉDIA  
**Estimativa:** 5 story points  
**Status:** REVISADO  
**Data de criação:** 24/09/2026  
**Última atualização:** 16/10/2026

**Breve descrição:**  
O sistema deve integrar e permitir o acesso sequenciado às funcionalidades desenvolvidas até a Semana 3: login, cadastro de cliente e pet, recuperação de senha e a nova **agenda** (RF-004), que permite agendar consultas e horários de retirada de produtos/medicamentos, com identificação de dias indisponíveis e pré-diagnóstico orientativo do animal.

---

## 1. Descrição detalhada

### 1.1 Por que este requisito existe?

A entrega integra as funcionalidades já desenvolvidas pelo grupo em um fluxo único de navegação, mantendo as telas originais e conectando-as de forma sequenciada.

O recurso deve:

- Apresentar a tela de login como ponto de entrada do protótipo.
- Disponibilizar acesso às funcionalidades desenvolvidas a partir do fluxo de navegação.
- Manter a identidade visual do PataSegura.
- Permitir navegação entre login, cadastro e recuperação de senha.
- Apresentar as funcionalidades de forma organizada e sequenciada.
- Informar o usuário sobre erros de validação e confirmações de ações.
- Permitir, pela barra lateral esquerda, o acesso à **Agenda** (RF-004) e ao cadastro de **Clientes e pets**.
- Permitir agendar consultas e horários de retirada de produtos/medicamentos, indicando os dias sem disponibilidade e sugerindo o próximo dia disponível.
- Registrar, na consulta, observações do tutor e apresentar um pré-diagnóstico orientativo sobre a situação do animal.

### 1.2 Contexto do negócio

O PataSegura é um sistema para gerenciamento de informações de um Pet Shop. Com a evolução do projeto, as funcionalidades desenvolvidas nas semanas anteriores precisam ser apresentadas de maneira integrada, permitindo uma navegação mais próxima do funcionamento de um sistema real.

---

## 2. Atores do sistema

### 2.1 Recepcionista — ator principal

- **Papel:** utilizar as funcionalidades operacionais do sistema.
- **Responsabilidade:** acessar o sistema, realizar o fluxo de cadastro de cliente e pet e solicitar recuperação de senha e agendar consultas e retiradas de produtos.
- **Permissões:**
  - CREATE: cadastrar cliente e pet; criar agendamentos de consulta e de retirada de produtos.
  - READ: visualizar as telas e dados apresentados pelo protótipo.
  - UPDATE: não implementado nesta entrega.
  - DELETE: cancelar agendamentos (apenas na agenda local do protótipo); demais exclusões não implementadas.

### 2.2 Administrador — ator secundário previsto

- **Papel:** responsável pela administração do sistema em uma evolução futura.
- **Responsabilidade:** acompanhar e administrar dados e permissões.
- **Permissões previstas:**
  - CREATE: permitido na evolução do sistema.
  - READ: permitido.
  - UPDATE: previsto.
  - DELETE: previsto.
- **Observação:** o papel administrativo não possui tela específica nesta entrega; foi identificado para delimitar responsabilidades futuras.

### 2.3 Sistema — ator automático

- **Papel:** processar as interações do protótipo.
- **Responsabilidade:** validar dados, apresentar mensagens e realizar os redirecionamentos entre telas.
- **Ações:** validar campos, exibir mensagens de erro/sucesso, direcionar a navegação, calcular a disponibilidade de datas e horários e gerar o pré-diagnóstico orientativo.

---

## 3. UC-005 — Navegar entre as funcionalidades e UC-006 — Agendar consulta ou retirada de produtos

### 3.1 Pré-condições

1. O navegador deve estar disponível.
2. O protótipo deve estar carregado.
3. Os arquivos HTML, CSS e JavaScript devem estar disponíveis nos caminhos definidos pela estrutura da Semana 09.

### 3.2 Pós-condições de sucesso

1. O usuário acessa o login.
2. O usuário consegue acessar cadastro ou recuperação de senha.
3. As validações das telas são apresentadas.
4. O usuário consegue retornar ao login.

### 3.3 Pós-condições de falha

1. Uma entrada inválida não deve concluir a ação correspondente.
2. O sistema deve apresentar uma mensagem de validação.
3. O usuário deve poder corrigir os dados e tentar novamente.

### 3.4 Fluxo principal

1. O usuário acessa a página inicial do protótipo.
2. O sistema redireciona o usuário para a tela de login.
3. O sistema apresenta os campos de e-mail e senha e as opções de acesso às demais funcionalidades.
4. O usuário informa o e-mail e a senha.
5. O usuário seleciona **Entrar**.
6. O sistema verifica se os campos obrigatórios foram preenchidos.
7. Se os campos estiverem inválidos, o sistema impede a conclusão da ação e apresenta a validação correspondente.
8. Se os campos estiverem válidos, o sistema processa o envio do formulário de login conforme o comportamento definido no protótipo.
9. O usuário pode selecionar **Criar cadastro** para acessar o RF-001.
10. O sistema carrega a tela de cadastro de cliente e pet.
11. O usuário pode retornar ao login por meio da opção de retorno.
12. O usuário informa o e-mail cadastrado e seleciona **Continuar**.
13. O sistema valida o formato do e-mail.
14. Em caso de validade, o sistema apresenta a tela de confirmação da solicitação.
15. O usuário pode retornar ao login e iniciar outro fluxo.
16. Na barra lateral esquerda, o usuário seleciona **Agenda** para acessar o RF-004, ou **Clientes e pets** para retornar ao RF-001.
17. As demais opções da barra lateral (Visão geral, Hospedagens e Relatórios) informam que a seção será entregue em etapa futura.

### 3.5 Fluxo alternativo A1 — Login com dados inválidos

1. O usuário acessa a tela de login.
2. O usuário deixa um ou mais campos obrigatórios vazios ou informa dados inválidos.
3. O usuário seleciona **Entrar**.
4. O navegador impede o envio quando um campo obrigatório não foi preenchido.
5. O usuário corrige os dados.
6. O usuário tenta novamente.

### 3.6 Fluxo alternativo A2 — Cadastro de cliente e pet

1. O usuário seleciona **Criar cadastro** na tela de login.
2. O sistema apresenta o formulário de cadastro.
3. O usuário informa os dados solicitados do cliente e do pet.
4. O sistema valida os campos durante o preenchimento e no envio.
5. Caso existam dados inválidos, o sistema apresenta o estado de erro correspondente.
6. O usuário corrige os dados.
7. Quando os dados estão válidos, o usuário seleciona **Salvar cadastro**.
8. O sistema apresenta o resultado do cadastro conforme o comportamento do protótipo.
9. O usuário pode retornar ao login.

### 3.7 Fluxo alternativo A3 — Recuperação de senha

1. O usuário seleciona **Esqueceu sua senha?** na tela de login.
2. O sistema apresenta o formulário de recuperação.
3. O usuário informa o e-mail.
4. O sistema verifica se o campo foi preenchido.
5. O sistema verifica se o valor informado possui formato de e-mail válido.
6. Se o valor for inválido, o sistema apresenta a mensagem de erro.
7. O usuário corrige o e-mail e tenta novamente.
8. Se o valor for válido, o sistema troca para o estado de confirmação.
9. O usuário seleciona **Voltar para o login**.
10. O sistema retorna à tela de login.

### 3.8 Fluxo alternativo A4 — Agendar consulta (UC-006)

1. O usuário seleciona **Agenda** na barra lateral e permanece na aba **Agendar consulta**.
2. O usuário informa tutor, pet, espécie e tipo de atendimento.
3. O usuário escolhe uma data no calendário (ou no campo de data). O sistema identifica visualmente os dias disponíveis, lotados e sem atendimento.
4. Se o dia escolhido não estiver disponível, o sistema exibe a mensagem com o motivo (data passada, domingo, feriado/recesso, agenda lotada ou fora do limite de 90 dias) e não permite concluir o agendamento.
5. Se o dia estiver disponível, o sistema lista os horários livres e o usuário escolhe um.
6. Alternativamente, o usuário seleciona **Próximo dia disponível** e o sistema preenche a data mais próxima com o primeiro horário livre.
7. Na aba **Observações e pré-diagnóstico**, o usuário informa faixa de idade, dias de evolução, sintomas e observações e seleciona **Gerar pré-diagnóstico**.
8. O sistema apresenta o nível de urgência, as hipóteses a investigar e as orientações. Para urgência alta ou emergência, o sistema seleciona o próximo dia disponível e alerta o usuário.
9. O usuário seleciona **Confirmar agendamento**; o sistema valida os campos, registra o agendamento e apresenta o protocolo.

### 3.9 Fluxo alternativo A5 — Agendar retirada de produtos/medicamentos (UC-006)

1. O usuário seleciona a aba **Retirada de produtos**.
2. O usuário informa tutor, pet, produto e quantidade. Para produtos que exigem receita, confirma que a apresentará no balcão.
3. O usuário escolhe um dia disponível para retirada; datas indisponíveis geram mensagem de erro com o motivo.
4. O usuário escolhe o horário (ou usa **Próximo dia disponível**) e confirma o agendamento.
5. O usuário pode consultar ou cancelar agendamentos na aba **Meus agendamentos**.

---

## 4. Regras de negócio

**RN-01:** As funcionalidades desenvolvidas até a Semana 3 devem estar conectadas e organizadas em um fluxo de navegação.

**RN-02:** O login deve ser o ponto de entrada do protótipo e deve oferecer acesso ao cadastro e à recuperação de senha.

**RN-03:** Os campos obrigatórios devem ser validados antes da confirmação da ação.

**RN-04:** O campo de e-mail deve ser considerado inválido quando estiver vazio ou não atender ao formato de e-mail aceito pelo navegador.

**RN-05:** Quando houver erro de validação, a interface deve informar o usuário e permitir a correção dos dados.

**RN-06:** Após uma solicitação de recuperação válida, o protótipo deve apresentar o estado visual de confirmação.

**RN-07:** As páginas integradas devem manter a identidade visual definida para o PataSegura.

**RN-08:** As opções de navegação devem utilizar caminhos relativos válidos entre os arquivos da Semana 09.

**RN-09:** A barra lateral esquerda deve levar à Agenda (RF-004) e a Clientes e pets (RF-001); seções ainda não desenvolvidas devem informar que estarão disponíveis em etapa futura.

**RN-10:** Consultas e retiradas só podem ser agendadas de segunda a sábado, em dias futuros ou hoje com horário restante, dentro dos próximos 90 dias. Consultas ocorrem das 09h às 17h (sábado até 13h) e retiradas das 08h às 18h (sábado até 12h), em intervalos de 30 minutos.

**RN-11:** Domingos, feriados nacionais, Sexta-feira Santa, recesso de fim de ano (24/12 e 31/12) e dias com todos os horários ocupados são indisponíveis. O calendário deve identificá-los (hachurado ou riscado) e, ao serem escolhidos, o sistema deve exibir mensagem de erro com o motivo e bloquear o agendamento.

**RN-12:** O sistema deve oferecer a opção **Próximo dia disponível**, que seleciona a data mais próxima com horário livre e o primeiro horário disponível.

**RN-13:** Um horário já reservado não pode ser reservado novamente para o mesmo serviço.

**RN-14:** Na retirada de produtos, a quantidade deve estar entre 1 e 10, e produtos que exigem receita só podem ser agendados com a confirmação de apresentação da receita.

**RN-15:** A consulta deve possuir aba de observações com sintomas, dias de evolução, faixa de idade e texto livre, e deve gerar pré-diagnóstico orientativo com urgência (baixa, moderada, alta ou emergência) e hipóteses a investigar.

**RN-16:** O pré-diagnóstico é apenas orientativo, não substitui o exame clínico e deve exibir essa advertência. Sintomas de emergência (dificuldade respiratória, convulsão, intoxicação, sangramento, abdômen inchado e duro) devem alertar o usuário a procurar atendimento imediato.

**RN-17:** O usuário deve poder consultar e cancelar seus agendamentos; o cancelamento libera o horário.

---

## 5. Requisitos não funcionais

**RNF-01 — Responsividade:** a interface deve permanecer utilizável em telas a partir de 320px de largura e em desktop de 1024px.

**RNF-02 — Tecnologia:** a camada de apresentação deve utilizar HTML5, CSS3 e JavaScript ES6+.

**RNF-03 — Usabilidade:** as ações principais devem possuir textos identificáveis e mensagens de validação compreensíveis.

**RNF-04 — Acessibilidade:** os campos devem possuir labels associados e a navegação deve ser utilizável por teclado sempre que aplicável.

**RNF-05 — Consistência visual:** as telas integradas devem preservar tipografia, cores, espaçamentos e identidade visual do PataSegura.

**RNF-06 — Navegação:** os links entre as funcionalidades devem utilizar caminhos relativos válidos e levar o usuário à tela correspondente.

**RNF-07 — Desempenho de interface:** as interações do protótipo devem apresentar resposta visual imediata nas validações locais, sem depender de servidor externo nesta entrega.

**RNF-08 — Disponibilidade do protótipo:** os arquivos necessários à execução local devem estar presentes na estrutura de diretórios definida para a Semana 09.

**RNF-09 — Persistência local:** os agendamentos devem ser mantidos no navegador (localStorage) enquanto não houver backend; a ausência do recurso não deve impedir o uso da tela.

**RNF-10 — Identificação visual da agenda:** dias disponíveis, lotados, sem atendimento e selecionado devem ser distinguidos por cor e por padrão (hachura/tachado), com legenda, para não depender apenas da cor.

---

## 6. Mockup / descrição das telas

### Tela 1 — Login

A tela de login é o ponto de entrada. Deve apresentar:

- identificação PataSegura;
- campo de e-mail;
- campo de senha;
- botão de entrada;
- link para recuperação de senha;
- link para criação de cadastro.

### Tela 2 — Cadastro de cliente e pet

A tela apresenta os dados necessários ao cadastro de cliente e pet, incluindo informações pessoais e informações do animal, além das ações de limpeza, salvamento e retorno.

### Tela 3 — Recuperação de senha

A tela apresenta:

- campo de e-mail;
- botão **Continuar**;
- mensagem de erro quando o e-mail for inválido;
- estado de confirmação após uma entrada válida;
- opção de retorno ao login.

### Tela 4 — Agenda (RF-004)

A tela mantém a barra lateral e o cabeçalho do sistema e apresenta:

- abas **Agendar consulta**, **Retirada de produtos** e **Meus agendamentos**;
- formulário do agendamento (tutor, pet, espécie e tipo de atendimento, ou produto, quantidade e receita), data e horário;
- na consulta, a aba **Observações e pré-diagnóstico** com sintomas, idade, dias de evolução, observações e o resultado orientativo;
- calendário mensal com legenda (disponível, lotado, sem atendimento, selecionado), mensagem de disponibilidade ou erro do dia escolhido e lista de horários;
- botão **Próximo dia disponível** e lista dos próximos dias sem disponibilidade;
- lista de agendamentos com opção de cancelar.

---

## 7. Tecnologias escolhidas

| Camada | Tecnologia | Versão | Justificativa |
|---|---|---|---|
| Estrutura | HTML5 | Atual | Estrutura semântica das telas e navegação |
| Estilização | CSS3 | Atual | Identidade visual, layout e responsividade |
| Interatividade | JavaScript | ES6+ | Validações, estados e navegação do protótipo |
| Backend futuro | Python | 3.12+ | Tecnologia prevista para as regras de negócio do projeto |

---

## 8. Arquitetura

### 8.1 Arquitetura atual da entrega

```text
┌───────────────────────────────────────────┐
│              CAMADA DE APRESENTAÇÃO       │
│                                           │
│ HTML5 + CSS3 + JavaScript                 │
│                                           │
│ RF-002 Login                               │
│     ├── RF-001 Cadastro ◄──► RF-004 Agenda  │
│     └── RF-003 Recuperação de senha        │
└─────────────────────┬─────────────────────┘
                      │
                      │ Navegação / validação local
                      ▼
┌───────────────────────────────────────────┐
│       REGRAS DE NEGÓCIO — FUTURO          │
│                                           │
│ Backend Python                            │
│ Validações persistentes / autenticação    │
└─────────────────────┬─────────────────────┘
                      │
                      ▼
┌───────────────────────────────────────────┐
│          PERSISTÊNCIA — FUTURA            │
│                                           │
│ Banco de dados                            │
│ Clientes / Pets / Usuários                │
└───────────────────────────────────────────┘
```

### 8.2 Fluxo de dados da entrega

```text
Usuário
   ↓
RF-002 Login
   ├── Criar cadastro ─────→ RF-001 Cadastro
   │                              ↓
   │                         validação local
   │
   └── Esqueceu senha ─────→ RF-003 Recuperação
                                  ↓
                             validação local
                                  ↓
                              confirmação
                                  ↓
                              RF-002 Login

RF-001 Cadastro ◄── barra lateral ──► RF-004 Agenda
                                        ↓
                      disponibilidade / validação / pré-diagnóstico
                                        ↓
                          agendamento (localStorage)
```

**Observação:** o backend Python e a persistência são previstos para etapas posteriores. Nesta entrega, a integração demonstrada é de protótipo, com navegação e validações no lado do cliente.

### 8.3 Padrão arquitetural

Para a evolução do sistema, será adotada uma separação em camadas, aproximando-se do padrão MVC:

- **View:** HTML e CSS das telas.
- **Controller:** JavaScript na camada de protótipo; posteriormente, controladores do backend.
- **Model:** entidades e regras de dados no backend, com persistência em banco.

---

## 9. ADR-005 — Integração das funcionalidades

**Status:** ACEITO

**Contexto:** As funcionalidades desenvolvidas nas primeiras semanas estavam apresentadas separadamente. A Semana 09 solicita que elas sejam sequenciadas em um fluxo de navegação.

**Decisão:** utilizar a tela de login como ponto de entrada e conectá-la ao cadastro de cliente/pet e à recuperação de senha, mantendo links de retorno entre as telas.

**Alternativas consideradas:**

1. Manter cada funcionalidade isolada.
2. Criar uma única tela estática sem navegação.
3. Integrar as funcionalidades por meio de navegação entre páginas.

**Motivo da escolha:** a terceira alternativa permite demonstrar a integração sem alterar a finalidade das telas já desenvolvidas.

**Consequências positivas:**

- fluxo de usuário mais próximo de um sistema real;
- funcionalidades acessíveis de forma organizada;
- identidade visual preservada;
- preparação para integração futura com backend.

**Consequências negativas:**

- a solução ainda depende de arquivos estáticos;
- autenticação e persistência reais ainda não estão implementadas nesta etapa.

---

## 10. ADR-006 — Uso de HTML5, CSS3 e JavaScript no protótipo

**Status:** ACEITO

**Contexto:** a Semana 09 exige a integração das telas desenvolvidas anteriormente e a demonstração da navegação em navegador.

**Decisão:** manter HTML5, CSS3 e JavaScript ES6+ como tecnologias da camada de apresentação do protótipo.

**Alternativas consideradas:**

1. Utilizar React ou Vue.
2. Manter HTML, CSS e JavaScript sem framework.
3. Utilizar apenas HTML estático.

**Motivo da escolha:** HTML, CSS e JavaScript atendem diretamente ao objetivo desta etapa, permitem execução local simples e preservam as tecnologias já utilizadas nas telas.

**Consequências:** menor complexidade de configuração nesta etapa e facilidade de execução local; frameworks podem ser avaliados posteriormente se a complexidade do sistema justificar.

---

## 11. ADR-007 — Separação em camadas para evolução do sistema

**Status:** ACEITO

**Contexto:** o protótipo atual concentra a interação no frontend, mas o projeto deverá evoluir para regras de negócio e persistência.

**Decisão:** organizar a evolução em apresentação, regras de negócio e persistência, utilizando uma abordagem próxima de MVC.

**Alternativas consideradas:**

1. Concentrar toda a lógica no frontend.
2. Manter um único arquivo com apresentação e regras.
3. Separar apresentação, regras e dados.

**Motivo da escolha:** a separação reduz acoplamento, facilita manutenção e permite substituir ou evoluir partes do sistema sem reescrever toda a interface.

**Consequências:** maior organização arquitetural e preparação para backend e banco de dados; exige disciplina na separação das responsabilidades nas próximas etapas.

---

---

## 12. ADR-008 — Agenda local com regras de disponibilidade e pré-diagnóstico orientativo

**Status:** ACEITO

**Contexto:** a agenda deve permitir agendar consultas e retiradas de produtos, identificar dias indisponíveis e apresentar um pré-diagnóstico do animal, ainda sem backend nem banco de dados.

**Decisão:** implementar o RF-004 em HTML, CSS e JavaScript, com as regras de calendário (domingos, feriados, recesso, lotação e janela de 90 dias) e o pré-diagnóstico por regras simples de sintomas executados no navegador. Os agendamentos ficam no localStorage. A ocupação inicial dos horários é simulada de forma determinística para demonstrar as mensagens de indisponibilidade.

**Alternativas consideradas:**

1. Agenda apenas visual, sem validações.
2. Agenda com regras no navegador e armazenamento local.
3. Agenda com backend Python e banco de dados desde já.

**Motivo da escolha:** a alternativa 2 demonstra o comportamento completo sem ampliar o escopo da etapa e mantém a lógica de disponibilidade isolada, pronta para migrar ao backend.

**Consequências positivas:** agenda funcional e demonstrável; regras de disponibilidade e de urgência documentadas; migração futura facilitada.

**Consequências negativas:** os dados valem apenas no navegador atual; a ocupação da agenda é simulada; o pré-diagnóstico não é clínico e deve ser substituído por avaliação do médico-veterinário.

---

# 10. Novos requisitos da evolução

## 10.1 RF-005 — Hospedagem de pets (entrega relacionada à Semana 8)

**Categoria:** Semana 8 — Hospedagem.  
**Tipo:** Requisito Funcional.  
**Objetivo:** permitir que a recepcionista consulte disponibilidade e reserve estadias para pets, acoplando a hospedagem à agenda operacional do PataSegura.

### Funcionalidades do RF-005

- Cadastrar uma reserva de hospedagem com tutor, pet, data de entrada e data de saída.
- Escolher a acomodação: suíte individual, acomodação compartilhada, berçário ou espaço sênior.
- Registrar rotina de alimentação, medicamentos, restrições e cuidados especiais.
- Identificar dias sem disponibilidade e impedir reservas nesses dias.
- Encontrar a próxima data disponível para hospedagem.
- Exibir histórico de hospedagens reservadas.
- Permitir cancelamento de uma reserva no protótipo.
- Manter os registros da demonstração no `localStorage` do navegador.

### UC-009 — Reservar hospedagem

**Ator principal:** Recepcionista.  
**Pré-condições:** o usuário está autenticado no protótipo e acessou Hospedagens pela agenda ou pela barra lateral.  
**Pós-condição de sucesso:** a estadia é criada com pet, período, acomodação e observações.  
**Pós-condição de falha:** a reserva não é criada; os campos inválidos são destacados e o dia sem disponibilidade permanece bloqueado.

**Fluxo principal:**

1. O usuário acessa a funcionalidade **Hospedagens**.
2. O sistema apresenta o calendário de disponibilidade de entradas.
3. O usuário informa tutor e pet.
4. O usuário escolhe a data de entrada.
5. O sistema informa se a data possui vaga.
6. O usuário informa a data de saída e a acomodação.
7. O usuário registra alimentação e cuidados especiais.
8. O usuário confirma as informações do pet.
9. O sistema salva a reserva e exibe a confirmação.

**Fluxo alternativo A1 — data sem disponibilidade:** o sistema identifica visualmente o dia como indisponível, impede sua seleção e oferece **Encontrar próxima data disponível**.

**Fluxo alternativo A2 — período inválido:** se a saída for anterior ou igual à entrada, o sistema exibe mensagem de erro e impede a confirmação até a correção.

### Regras de negócio do RF-005

**RN-18:** hospedagens devem possuir data de entrada e saída válidas.  
**RN-19:** a data de saída deve ser posterior à data de entrada.  
**RN-20:** domingos e dias sem vaga devem ser identificados e não podem iniciar uma hospedagem.  
**RN-21:** o tutor deve confirmar que os dados do pet estão atualizados antes da reserva.  
**RN-22:** observações de medicamentos e restrições devem acompanhar a reserva de hospedagem.

## 10.2 RF-006 — Reservas e consulta médica (entrega da Semana 9)

**Categoria:** Semana 9 — Reserva e consulta médica.  
**Tipo:** Requisito Funcional.  
**Objetivo:** permitir reservar consultas médicas veterinárias e manter um histórico de prontuários com gestão de anamnese, medicamentos e exame.

### Funcionalidades do RF-006

- Reservar consulta por tutor, pet, especialidade, data, horário e motivo.
- Exibir apenas horários disponíveis e impedir conflitos de reserva.
- Encontrar o próximo horário livre para consulta.
- Registrar observação inicial informada pelo tutor.
- Criar prontuário médico para o pet.
- Registrar anamnese, medicamentos em uso, exame ou avaliação clínica e plano de retorno.
- Consultar o histórico de consultas médicas e prontuários.
- Excluir um registro de prontuário no protótipo local.
- Manter reservas e prontuários no `localStorage` da demonstração.

### UC-010 — Reservar consulta médica veterinária

**Ator principal:** Recepcionista.  
**Pré-condições:** a agenda médica está disponível e o pet foi identificado.  
**Pós-condição de sucesso:** a consulta é reservada com data, horário e especialidade.  
**Pós-condição de falha:** a reserva não é criada se houver conflito, data indisponível ou campo obrigatório ausente.

**Fluxo principal:**

1. O usuário acessa **Consultas médicas** pela agenda ou pela barra lateral.
2. O usuário informa tutor e pet.
3. O usuário seleciona a especialidade.
4. O usuário seleciona uma data futura disponível.
5. O sistema lista horários livres.
6. O usuário informa o motivo e a observação inicial.
7. O usuário seleciona **Confirmar reserva**.
8. O sistema registra a consulta e bloqueia o horário reservado.

**Fluxo alternativo A1 — horário já reservado:** o sistema desabilita o horário, informa o conflito e solicita outra escolha.

**Fluxo alternativo A2 — data sem atendimento:** o sistema identifica a data sem disponibilidade, apresenta o motivo e oferece o próximo horário livre.

### UC-011 — Gerenciar prontuário médico

**Ator principal:** Médico-veterinário.  
**Pré-condições:** o pet e a data do exame estão identificados.  
**Pós-condição de sucesso:** o histórico do pet recebe um prontuário com anamnese, medicamentos, exame e plano de retorno.  
**Pós-condição de falha:** o registro não é salvo enquanto campos obrigatórios estiverem vazios.

**Fluxo principal:**

1. O profissional acessa a aba **Gestão de prontuário**.
2. O sistema apresenta os campos do atendimento clínico.
3. O profissional informa o pet e a data do exame.
4. O profissional registra a anamnese.
5. O profissional registra medicamentos em uso ou informa que não há medicamentos.
6. O profissional registra o exame e a avaliação clínica.
7. O profissional registra plano e retorno, quando aplicável.
8. O sistema salva o prontuário no histórico médico.

**Fluxo alternativo A1 — anamnese incompleta:** o sistema destaca a anamnese e impede o salvamento até que a queixa, histórico ou evolução sejam registrados.

**Fluxo alternativo A2 — exame não informado:** o sistema exige o campo de exame/avaliação clínica e mantém o formulário aberto para correção.

### Gestão do prontuário

O prontuário do RF-006 é dividido em quatro partes:

1. **Anamnese:** queixa principal, histórico, sinais observados e evolução.
2. **Medicamentos:** nome, dose, frequência e medicamentos em uso pelo animal.
3. **Exame:** sinais vitais, achados do exame físico, avaliação e hipótese clínica.
4. **Plano e retorno:** conduta, recomendações e data de acompanhamento.

### Regras de negócio do RF-006

**RN-23:** uma reserva de consulta deve possuir pet, especialidade, data, horário e motivo.  
**RN-24:** o mesmo horário não pode ser reservado novamente para uma consulta médica.  
**RN-25:** consultas devem ocorrer somente em datas e horários disponíveis.  
**RN-26:** o prontuário deve conter anamnese e exame/avaliação clínica.  
**RN-27:** o campo de medicamentos deve registrar os medicamentos em uso ou a ausência deles.  
**RN-28:** o histórico deve identificar o pet e a data de cada consulta.  
**RN-29:** dados clínicos do prontuário são demonstrativos nesta etapa e não substituem um sistema médico veterinário seguro.

## 10.3 Arquitetura e organização dos novos requisitos

```text
SEMANA-09/
├── index.html
├── docs/requisitos-semanais/SEMANA-09/documentacao.md
└── src/prototipos/SEMANA-09/
    ├── RF-001-cadastro/
    ├── RF-002-login/
    ├── RF-003-recuperar-senha/
    ├── RF-004-agenda/
    ├── RF-005-hospedagem/          # Parte da Semana 8
    │   ├── RF-05.html
    │   ├── style.css
    │   └── script.js
    └── RF-006-reservas-consulta/   # Semana 9
        ├── RF-06.html
        ├── style.css
        └── script.js
```

A agenda RF-004 permanece como funcionalidade anterior e passa a encaminhar para RF-005 e RF-006. O RF-005 representa a entrega de hospedagem relacionada à Semana 8; o RF-006 representa a entrega atual da Semana 9, com reservas e consulta médica.

## 10.4 ADR-010 — Acoplamento da hospedagem à agenda

**Status:** ACEITO.  
**Decisão:** manter a hospedagem em uma tela própria, acessível pela agenda e pela barra lateral, utilizando regras de disponibilidade e armazenamento local compatíveis com a agenda existente.  
**Consequência:** o fluxo de hospedagem fica separado por responsabilidade, mas integrado na navegação operacional.

## 10.5 ADR-011 — Prontuário médico estruturado

**Status:** ACEITO.  
**Decisão:** representar o prontuário em campos separados de anamnese, medicamentos, exame e plano de retorno.  
**Justificativa:** a separação facilita leitura, validação e futura migração para entidades persistentes.  
**Limitação:** o protótipo não deve ser usado como prontuário clínico real; os dados ficam apenas no navegador.
