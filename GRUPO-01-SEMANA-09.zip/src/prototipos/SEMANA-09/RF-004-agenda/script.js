const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];

/* ---------- Armazenamento local (protótipo sem backend) ---------- */
const KEY = 'patasegura_agenda_v1';
let memoria = [];
const carregar = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return memoria; } };
const gravar = l => { memoria = l; try { localStorage.setItem(KEY, JSON.stringify(l)); } catch (e) {} };

/* ---------- Regras de disponibilidade ---------- */
const SERV = {
  consulta: { nome: 'atendimento', ini: 9, fim: 17, sab: 13 },
  retirada: { nome: 'retirada de produtos', ini: 8, fim: 18, sab: 12 }
};
const FERIADOS = {
  '01-01': 'Confraternização Universal', '04-21': 'Tiradentes', '05-01': 'Dia do Trabalho',
  '09-07': 'Independência do Brasil', '10-12': 'Nossa Senhora Aparecida', '11-02': 'Finados',
  '11-15': 'Proclamação da República', '11-20': 'Consciência Negra', '12-25': 'Natal',
  '12-24': 'recesso de fim de ano', '12-31': 'recesso de fim de ano'
};
const agora = new Date();
const hoje0 = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate());
const limite = new Date(hoje0); limite.setDate(limite.getDate() + 90);

const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const paraData = s => { const [a, b, c] = s.split('-'); return new Date(+a, b - 1, +c); };
const fmt = d => d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' });
const hash = s => { let x = 0; for (const c of s) x = (x * 31 + c.charCodeAt(0)) >>> 0; return x % 100; };

function pascoa(y) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4,
    f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30,
    i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7,
    m = Math.floor((a + 11 * h + 22 * l) / 451), mes = Math.floor((h + l - 7 * m + 114) / 31),
    dia = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(y, mes - 1, dia);
}
function sextaSanta(y) { const p = pascoa(y); p.setDate(p.getDate() - 2); return iso(p); }

/* Horários do dia. Parte da agenda é simulada como já ocupada (determinística) e
   alguns dias ficam lotados, para demonstrar as mensagens de indisponibilidade. */
function horarios(tipo, ds) {
  const d = paraData(ds), c = SERV[tipo], fim = d.getDay() === 6 ? c.sab : c.fim;
  const reservados = carregar().filter(a => a.tipo === tipo && a.data === ds).map(a => a.hora);
  const lotado = hash('L' + tipo + ds) < 8;
  const minAgora = agora.getHours() * 60 + agora.getMinutes() + 30;
  const out = [];
  for (let m = c.ini * 60; m < fim * 60; m += 30) {
    const hr = String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
    const passou = ds === iso(hoje0) && m <= minAgora;
    const livre = !lotado && hash(tipo + ds + hr) >= 35 && !reservados.includes(hr) && !passou;
    out.push({ hr, livre, passou });
  }
  return out;
}

function status(tipo, ds) {
  const d = paraData(ds), n = SERV[tipo].nome;
  if (d < hoje0) return { ok: false, c: 'past', m: 'Data já passada. Escolha hoje ou uma data futura.' };
  if (d > limite) return { ok: false, c: 'off', m: 'A agenda está aberta apenas para os próximos 90 dias.' };
  if (d.getDay() === 0) return { ok: false, c: 'off', m: `Domingo: sem ${n}. A unidade funciona de segunda a sábado.` };
  const f = FERIADOS[ds.slice(5)] || (ds === sextaSanta(d.getFullYear()) ? 'Sexta-feira Santa' : '');
  if (f) return { ok: false, c: 'off', m: `Sem ${n} em ${fmt(d)}: ${f}.` };
  const hs = horarios(tipo, ds), livres = hs.filter(x => x.livre).length;
  if (!livres) {
    const encerrado = ds === iso(hoje0) && hs.some(x => x.passou);
    return { ok: false, c: 'full', m: encerrado ? `Hoje não há mais horários disponíveis para ${n}.` : `Agenda lotada em ${fmt(d)}: todos os horários já foram reservados.` };
  }
  return { ok: true, c: 'free', livres, m: `Dia disponível: ${livres} horário(s) livre(s) para ${n}.` };
}

/* ---------- Estado e interface ---------- */
const S = { tipo: 'consulta', mes: new Date(hoje0.getFullYear(), hoje0.getMonth(), 1), data: '', hora: '', pre: null };

function toast(titulo, texto, tipo) {
  const t = $('#toast');
  t.classList.toggle('error-toast', tipo === 'error');
  $('#toastIcon').textContent = tipo === 'error' ? '!' : '✓';
  $('#toastTitle').textContent = titulo; $('#toastText').textContent = texto;
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3800);
}

function mostrarDia() {
  const box = $('#dayMsg'), slots = $('#slots');
  slots.innerHTML = '';
  if (!S.data) { box.className = 'daymsg'; return; }
  const st = status(S.tipo, S.data);
  box.className = 'daymsg ' + (st.ok ? 'ok' : 'err'); box.textContent = st.m;
  if (!st.ok) return;
  horarios(S.tipo, S.data).forEach(h => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = h.hr; b.disabled = !h.livre;
    b.className = 'slot' + (S.hora === h.hr ? ' sel' : '');
    b.title = h.livre ? 'Horário livre' : (h.passou ? 'Horário já passou' : 'Horário indisponível');
    b.onclick = () => { S.hora = h.hr; $('#hora').value = h.hr; marcar('hora', ''); mostrarDia(); };
    slots.appendChild(b);
  });
}

function calendario() {
  const y = S.mes.getFullYear(), m = S.mes.getMonth(), g = $('#cal');
  $('#mesTitulo').textContent = S.mes.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  g.innerHTML = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(x => `<span class="wd">${x}</span>`).join('');
  for (let i = 0; i < new Date(y, m, 1).getDay(); i++) g.insertAdjacentHTML('beforeend', '<span class="day blank"></span>');
  for (let d = 1; d <= new Date(y, m + 1, 0).getDate(); d++) {
    const ds = iso(new Date(y, m, d)), st = status(S.tipo, ds), b = document.createElement('button');
    b.type = 'button'; b.textContent = d; b.title = st.m;
    b.className = 'day ' + st.c + (ds === iso(hoje0) ? ' today' : '') + (ds === S.data ? ' sel' : '');
    b.setAttribute('aria-label', `${d}: ${st.ok ? 'disponível' : 'indisponível'}`);
    b.onclick = () => escolherData(ds);
    g.appendChild(b);
  }
  $('#prev').disabled = S.mes <= new Date(hoje0.getFullYear(), hoje0.getMonth(), 1);
  $('#next').disabled = S.mes >= new Date(limite.getFullYear(), limite.getMonth(), 1);
  indisponiveis();
}

function indisponiveis() {
  const itens = [];
  for (let i = 0; i <= 45 && itens.length < 6; i++) {
    const d = new Date(hoje0); d.setDate(d.getDate() + i);
    if (d.getDay() === 0) continue;
    const st = status(S.tipo, iso(d));
    if (!st.ok) itens.push(`<li><b>${d.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' })}</b> — ${st.c === 'full' ? 'agenda lotada' : st.m.split(': ').pop().replace(/\.$/, '')}</li>`);
  }
  $('#unav').innerHTML = `<b>Próximos dias sem disponibilidade (exceto domingos)</b>${itens.length ? '<ul>' + itens.join('') + '</ul>' : '<br>Nenhum nos próximos 45 dias.'}`;
}

function escolherData(ds) {
  S.data = ds; S.hora = ''; $('#hora').value = ''; $('#data').value = ds;
  const d = paraData(ds); S.mes = new Date(d.getFullYear(), d.getMonth(), 1);
  const st = status(S.tipo, ds);
  marcar('data', st.ok ? '' : st.m);
  calendario(); mostrarDia();
  if (!st.ok) toast('Data indisponível', st.m, 'error');
}

function proximoDia() {
  for (let i = 0; i <= 90; i++) {
    const d = new Date(hoje0); d.setDate(d.getDate() + i);
    const ds = iso(d), st = status(S.tipo, ds);
    if (st.ok) {
      escolherData(ds);
      const h = horarios(S.tipo, ds).find(x => x.livre);
      S.hora = h.hr; $('#hora').value = h.hr; marcar('hora', ''); mostrarDia();
      toast('Próximo dia disponível', `${fmt(d)} às ${h.hr}. Confirme para concluir.`);
      return true;
    }
  }
  toast('Sem disponibilidade', 'Não há dias disponíveis nos próximos 90 dias.', 'error');
  return false;
}

function marcar(id, msg) {
  const el = $('#' + id), f = el.closest('.field');
  f.classList.toggle('has-error', !!msg); f.querySelector('.error').textContent = msg || '';
  el.classList.toggle('invalid', !!msg);
  return !msg;
}

/* ---------- Abas ---------- */
function abrirAba(t) {
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
  const meus = t === 'meus';
  $('#areaAgendar').classList.toggle('hidden', meus);
  $('#painelMeus').classList.toggle('hidden', !meus);
  $('#crumb').textContent = { consulta: 'Agendar consulta', retirada: 'Retirada de produtos', meus: 'Meus agendamentos' }[t];
  if (meus) { listar(); return; }
  S.tipo = t; S.data = ''; S.hora = '';
  $('#data').value = ''; $('#hora').value = '';
  $$('[data-for]').forEach(e => e.classList.toggle('hidden', e.dataset.for !== t));
  $('#formTitulo').textContent = t === 'consulta' ? 'Agendar consulta' : 'Retirada de produtos';
  $('#formSub').textContent = t === 'consulta' ? 'Informe os dados do atendimento e a observação do pet' : 'Escolha o produto e o dia disponível para retirar no balcão';
  $$('.field').forEach(f => { f.classList.remove('has-error'); f.querySelector('.error') && (f.querySelector('.error').textContent = ''); });
  $$('.invalid').forEach(i => i.classList.remove('invalid'));
  painel('dados'); atualizarReceita(); calendario(); mostrarDia();
}
function painel(p) {
  $$('.subtab').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  $('#pane-dados').classList.toggle('hidden', p !== 'dados');
  $('#pane-obs').classList.toggle('hidden', p !== 'obs' || S.tipo !== 'consulta');
}
function atualizarReceita() {
  const opt = $('#produto').selectedOptions[0];
  $('#boxReceita').classList.toggle('hidden', !(S.tipo === 'retirada' && opt && opt.dataset.rx));
}

/* ---------- Pré-diagnóstico (regras orientativas do protótipo) ---------- */
const SINT = {
  vomito: 'Vômito', diarreia: 'Diarreia', apetite: 'Falta de apetite', apatia: 'Apatia / muito sono',
  coceira: 'Coceira intensa', pelo: 'Queda de pelo ou feridas na pele', orelha: 'Balança a cabeça / secreção no ouvido',
  tosse: 'Tosse ou espirros', olho: 'Olho vermelho ou com secreção', manca: 'Manqueira / dor ao tocar',
  sede: 'Sede excessiva / urina com frequência', febre: 'Febre (corpo quente)', respira: 'Dificuldade para respirar',
  convulsao: 'Convulsão ou tremores', sangue: 'Sangramento', toxico: 'Ingeriu produto tóxico, planta ou medicamento',
  abdome: 'Barriga inchada e dura'
};
const EMERGENCIA = ['respira', 'convulsao', 'toxico', 'sangue', 'abdome'];
const CONDICOES = [
  { n: 'Gastroenterite ou indiscrição alimentar', s: { vomito: 3, diarreia: 3, apetite: 2, apatia: 1 }, o: 'Ofereça água em pequenas quantidades e evite alimentos novos até a consulta.' },
  { n: 'Parasitose intestinal ou externa', s: { diarreia: 2, apetite: 1, coceira: 2, pelo: 2 }, o: 'Leve informações sobre vermifugação e antipulgas em uso.' },
  { n: 'Dermatite alérgica, pulgas ou sarna', s: { coceira: 3, pelo: 3 }, o: 'Evite banhos com produtos próprios e impeça que o pet se lamba ou coce em excesso.' },
  { n: 'Otite', s: { orelha: 4, coceira: 1 }, o: 'Não aplique produtos no ouvido sem orientação do veterinário.' },
  { n: 'Infecção respiratória (tosse dos canis / gripe felina)', s: { tosse: 3, febre: 2, apatia: 1, apetite: 1 }, o: 'Mantenha o pet em ambiente aquecido, ventilado e separado de outros animais.' },
  { n: 'Conjuntivite ou lesão ocular', s: { olho: 4, coceira: 1 }, o: 'Limpe apenas com soro fisiológico e evite que o pet coce o olho.' },
  { n: 'Lesão ortopédica ou muscular', s: { manca: 4, apatia: 1 }, o: 'Restrinja a movimentação e evite escadas e pulos.' },
  { n: 'Alteração urinária ou renal', s: { sede: 4, apetite: 1, apatia: 1, vomito: 1 }, o: 'Mantenha água fresca disponível e observe a frequência e a cor da urina.' },
  { n: 'Infecção sistêmica ou doença transmitida por carrapato', s: { febre: 3, apatia: 2, apetite: 2, sangue: 2 }, o: 'Verifique a presença de carrapatos e anote a temperatura, se possível.' },
  { n: 'Possível intoxicação', s: { toxico: 5, vomito: 2, convulsao: 2, apatia: 1 }, o: 'Leve a embalagem do produto ou da planta ingerida.' },
  { n: 'Quadro neurológico', s: { convulsao: 5, apatia: 1 }, o: 'Mantenha o pet em local seguro, sem forçar movimentos.' },
  { n: 'Desconforto respiratório ou cardíaco', s: { respira: 5, tosse: 2, apatia: 1 }, o: 'Evite estresse e calor; mantenha o pet calmo.' },
  { n: 'Emergência abdominal (ex.: torção gástrica)', s: { abdome: 5, vomito: 1, apatia: 1 }, o: 'Não ofereça água nem comida.' }
];
const NIVEIS = ['Baixa', 'Moderada', 'Alta', 'Emergência'];
const ORIENT = [
  'Atendimento de rotina na data escolhida.',
  'Agende nos próximos dias e observe a evolução.',
  'Agende o mais cedo possível. O próximo dia disponível foi selecionado para você.',
  'Emergência: não aguarde a data da consulta e procure um pronto atendimento veterinário agora.'
];

function gerarPre() {
  const sel = $$('#sintomas input:checked').map(i => i.value);
  const dias = +$('#dias').value || 0, idade = $('#idade').value;
  const box = $('#pre');
  if (!sel.length) {
    S.pre = { urg: 0, nivel: NIVEIS[0], hip: [], orient: 'Nenhum sintoma informado: atendimento de rotina ou check-up.' };
  } else {
    let urg = sel.some(x => EMERGENCIA.includes(x)) ? 3 : sel.length >= 4 ? 2 : sel.length >= 2 || sel.includes('febre') ? 1 : 0;
    if (urg < 2 && dias >= 3) urg++;
    if (urg < 2 && idade !== 'adulto' && sel.some(x => ['vomito', 'diarreia', 'apetite', 'apatia'].includes(x))) urg++;
    const hip = CONDICOES.map(c => {
      const tot = Object.values(c.s).reduce((a, b) => a + b, 0), got = sel.reduce((a, k) => a + (c.s[k] || 0), 0);
      return { n: c.n, o: c.o, p: got / tot };
    }).filter(c => c.p >= .34).sort((a, b) => b.p - a.p).slice(0, 3)
      .map(c => ({ n: c.n, o: c.o, comp: c.p >= .7 ? 'alta' : c.p >= .45 ? 'média' : 'baixa' }));
    S.pre = { urg, nivel: NIVEIS[urg], hip, orient: ORIENT[urg], sint: sel.map(k => SINT[k]) };
  }
  const p = S.pre;
  box.className = 'pre show';
  box.innerHTML = `<b>Pré-diagnóstico orientativo</b><span class="urg u${p.urg}">Urgência: ${p.nivel}</span>` +
    (p.hip.length ? `<p><b>Hipóteses a investigar:</b></p><ul>${p.hip.map(h => `<li>${h.n} — compatibilidade ${h.comp}. ${h.o}</li>`).join('')}</ul>` : '') +
    `<p>${p.orient}</p><p class="hint">Resultado gerado por regras simples do protótipo. Não substitui o exame clínico nem o diagnóstico do médico-veterinário.</p>`;
  if (p.urg >= 2 && !S.data) proximoDia();
  if (p.urg === 3) toast('Possível emergência', 'Procure um pronto atendimento veterinário imediatamente.', 'error');
  return p;
}

/* ---------- Confirmação ---------- */
function validar() {
  let ok = true;
  const v = (c, id, m) => { if (!marcar(id, c ? '' : m)) ok = false; };
  v($('#tutor').value.trim().length >= 3, 'tutor', 'Informe o nome do tutor.');
  v($('#pet').value.trim(), 'pet', 'Informe o nome do pet.');
  if (S.tipo === 'consulta') {
    v($('#especie').value, 'especie', 'Selecione a espécie.');
    v($('#servico').value, 'servico', 'Selecione o tipo de atendimento.');
  } else {
    v($('#produto').value, 'produto', 'Selecione o produto.');
    const q = +$('#qtd').value;
    v(Number.isInteger(q) && q >= 1 && q <= 10, 'qtd', 'Informe uma quantidade entre 1 e 10.');
    if (!$('#boxReceita').classList.contains('hidden')) v($('#receita').checked, 'receita', 'Este produto exige receita veterinária.');
  }
  const st = S.data ? status(S.tipo, S.data) : null;
  v(st && st.ok, 'data', S.data ? st.m : 'Escolha uma data disponível no calendário.');
  v(S.hora, 'hora', 'Escolha um horário disponível.');
  return ok;
}

$('#form').onsubmit = e => {
  e.preventDefault();
  painel('dados');
  if (!validar()) { toast('Revise os campos', 'Há informações pendentes ou datas indisponíveis.', 'error'); return; }
  if (!carregar().every(a => !(a.tipo === S.tipo && a.data === S.data && a.hora === S.hora))) {
    toast('Horário indisponível', 'Este horário acabou de ser reservado. Escolha outro.', 'error'); mostrarDia(); return;
  }
  const a = {
    id: 'PS-' + Date.now().toString(36).toUpperCase().slice(-6), tipo: S.tipo, data: S.data, hora: S.hora,
    tutor: $('#tutor').value.trim(), pet: $('#pet').value.trim()
  };
  if (S.tipo === 'consulta') {
    a.especie = $('#especie').value; a.servico = $('#servico').value;
    const temObs = $$('#sintomas input:checked').length || $('#obsTexto').value.trim();
    a.obs = $('#obsTexto').value.trim();
    a.pre = S.pre || (temObs ? gerarPre() : null);
  } else {
    a.produto = $('#produto').value; a.qtd = +$('#qtd').value;
  }
  gravar([...carregar(), a]);
  const d = paraData(a.data);
  $('#modalTitulo').textContent = S.tipo === 'consulta' ? 'Consulta agendada' : 'Retirada agendada';
  $('#modalTexto').textContent = `Protocolo ${a.id}: ${a.pet} (tutor ${a.tutor}) em ${fmt(d)} às ${a.hora}.` + (a.pre ? ` Urgência estimada: ${a.pre.nivel}.` : '');
  $('#modal').classList.add('show');
};
$('#closeModal').onclick = () => {
  $('#modal').classList.remove('show');
  $('#form').reset(); S.pre = null; $('#pre').className = 'pre';
  abrirAba(S.tipo);
  toast('Agendamento salvo!', 'Consulte em "Meus agendamentos".');
};

/* ---------- Meus agendamentos ---------- */
function listar() {
  const l = carregar().sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));
  $('#listaMeus').innerHTML = l.length ? l.map(a => {
    const d = fmt(paraData(a.data));
    const info = a.tipo === 'consulta' ? `${a.servico} · ${a.especie}` : `${a.produto} · qtd ${a.qtd}`;
    const pre = a.pre ? `<p>Pré-diagnóstico: <span class="urg u${a.pre.urg}">${a.pre.nivel}</span> ${a.pre.hip.map(h => h.n).join('; ')}</p>` : '';
    return `<div class="appt"><div><h3>${a.tipo === 'consulta' ? 'Consulta' : 'Retirada'} · ${a.pet} <small>(${a.id})</small></h3><p>${d} às ${a.hora} · Tutor: ${a.tutor}</p><p>${info}</p>${pre}${a.obs ? `<p>Obs.: ${a.obs.replace(/</g, '&lt;')}</p>` : ''}</div><div><button class="btn secondary" type="button" data-cancelar="${a.id}">Cancelar</button></div></div>`;
  }).join('') : '<div class="card"><div class="card-body">Nenhum agendamento realizado ainda.</div></div>';
  $$('[data-cancelar]').forEach(b => b.onclick = () => {
    if (!confirm('Cancelar este agendamento?')) return;
    gravar(carregar().filter(x => x.id !== b.dataset.cancelar));
    listar(); toast('Agendamento cancelado', 'O horário voltou a ficar disponível.');
  });
}

/* ---------- Inicialização ---------- */
$('#hoje').textContent = 'Hoje, ' + agora.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).replace('.', '');
$('#data').min = iso(hoje0);
$('#sintomas').innerHTML = Object.entries(SINT).map(([k, v]) => `<label class="check"><input type="checkbox" value="${k}"> ${v}</label>`).join('');
$$('.tab').forEach(b => b.onclick = () => abrirAba(b.dataset.tab));
$$('.subtab').forEach(b => b.onclick = () => painel(b.dataset.pane));
$('#prev').onclick = () => { S.mes = new Date(S.mes.getFullYear(), S.mes.getMonth() - 1, 1); calendario(); };
$('#next').onclick = () => { S.mes = new Date(S.mes.getFullYear(), S.mes.getMonth() + 1, 1); calendario(); };
$('#proximo').onclick = proximoDia;
$('#gerarPre').onclick = gerarPre;
$('#produto').onchange = atualizarReceita;
$('#data').onchange = e => e.target.value ? escolherData(e.target.value) : null;
$$('#form input[type=text],#form select,#form input[type=number]').forEach(i => i.addEventListener('input', () => i.id && i.closest('.field') && !['data', 'hora'].includes(i.id) && marcar(i.id, '')));
$$('[data-soon]').forEach(a => a.onclick = e => { e.preventDefault(); toast('Em breve', 'Esta seção será entregue em uma próxima etapa.', 'error'); });
abrirAba('consulta');
