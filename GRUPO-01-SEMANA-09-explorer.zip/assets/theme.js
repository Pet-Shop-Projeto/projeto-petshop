(function () {
  const key = 'patasegura-theme';
  const saved = localStorage.getItem(key);
  const root = document.documentElement;
  if (saved === 'dark') root.dataset.theme = 'dark';

  function updateButton(button) {
    const dark = root.dataset.theme === 'dark';
    button.textContent = dark ? '☀ Modo claro' : '☾ Modo escuro';
    button.setAttribute('aria-pressed', String(dark));
    button.setAttribute('aria-label', dark ? 'Ativar modo claro' : 'Ativar modo escuro');
  }

  function init() {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'theme-toggle';
    button.addEventListener('click', function () {
      const dark = root.dataset.theme === 'dark';
      root.dataset.theme = dark ? 'light' : 'dark';
      localStorage.setItem(key, dark ? 'light' : 'dark');
      updateButton(button);
    });
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
      const note = sidebar.querySelector('.side-note');
      if (note) sidebar.insertBefore(button, note);
      else sidebar.appendChild(button);
    } else {
      document.body.appendChild(button);
    }
    updateButton(button);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
